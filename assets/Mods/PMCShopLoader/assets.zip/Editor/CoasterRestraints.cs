﻿using System.Collections;
using System.Collections.Generic;
using Newtonsoft.Json;
using UnityEditor;
using UnityEngine;

namespace ParkitectAssetEditor
{
    public class CoasterRestraints
    {
		public string TransformName;
        public float ClosedAngle;
	}
}
