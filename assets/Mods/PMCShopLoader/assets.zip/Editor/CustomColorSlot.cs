﻿namespace ParkitectAssetEditor
{
    /// <summary>
    /// One of the four available slots for custom colors
    /// </summary>
    enum CustomColorSlot
    {
	    Color1 = 0,
		Color2 = 1,
		Color3 = 2,
		Color4 = 3
	}
}
